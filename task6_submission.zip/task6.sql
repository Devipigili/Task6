-- Create example tables
CREATE TABLE Customers (
    CustomerID INT PRIMARY KEY,
    Name VARCHAR(100),
    City VARCHAR(50)
);

CREATE TABLE Orders (
    OrderID INT PRIMARY KEY,
    CustomerID INT,
    Amount DECIMAL(10, 2),
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

-- Subquery in SELECT (scalar subquery)
SELECT Name, 
       (SELECT COUNT(*) FROM Orders WHERE Orders.CustomerID = Customers.CustomerID) AS OrderCount
FROM Customers;

-- Subquery in WHERE (IN)
SELECT Name 
FROM Customers 
WHERE CustomerID IN (SELECT CustomerID FROM Orders WHERE Amount > 1000);

-- Subquery using EXISTS
SELECT Name 
FROM Customers c
WHERE EXISTS (
    SELECT 1 FROM Orders o WHERE o.CustomerID = c.CustomerID AND o.Amount > 500
);

-- Subquery in FROM clause (derived table)
SELECT City, AVG(OrderTotal) as AvgOrder
FROM (
    SELECT c.City, o.Amount AS OrderTotal
    FROM Customers c
    JOIN Orders o ON c.CustomerID = o.CustomerID
) AS DerivedTable
GROUP BY City;
# Task 6: Subqueries and Nested Queries

## Objective
Use subqueries in SELECT, WHERE, and FROM clauses to retrieve and filter data with advanced SQL logic.

## Tables Used
- Customers
- Orders

## Subqueries Demonstrated
- Scalar subquery in SELECT
- Subquery with IN in WHERE clause
- EXISTS clause
- Subquery in FROM clause (Derived table)

## Output
Returns filtered and aggregated customer data using nested SQL logic.